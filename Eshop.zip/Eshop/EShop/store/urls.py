from django.contrib import admin
from django.urls import path, include
from store.views.login import Login
from store.views.signup import Singup
from store.views.home import IndexView
from store.views.logout import logout
from store.views.cart import Cart
from store.views.checkout import CheckOut
from store.views.orders import OrderView
from .middleware.auth import auth_middleware

app_name = 'store'
urlpatterns = [
    path('', IndexView.as_view(), name='home'),
    path('login/', Login.as_view(), name='login'),
    path('signup/', Singup.as_view(), name='signup'),
    path('logout/', logout, name='logout'),
    path('cart/', Cart.as_view(), name='cart'),
    path('check-out', CheckOut.as_view(), name='checkout'),
    path('orders/', OrderView.as_view(), name='order'),
]