from django.db import models
from .products import Product
from  .customers import Customer
import datetime
from django.utils.timezone import now


class OrderedData(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    name = models.CharField(max_length=50, default='')
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    address = models.CharField(max_length=200, default='')
    pincode = models.IntegerField(null=True)
    mobile = models.CharField(max_length=10, default='')
    tm = datetime.datetime.now()
    order_date = models.DateTimeField(blank=True, null=True,default=now)
    status = models.BooleanField(default=False)
    def place_order(self):
        self.save()

    @staticmethod
    def get_orders_by_customer(customer):
        print(customer)
        if customer:
            return OrderedData.objects.filter(customer=customer).order_by('-order_date')
        
    @staticmethod
    def get_orders_by_email(email_id):
        print(email_id)
        if email_id:
            return OrderedData.objects.filter(email=email_id)