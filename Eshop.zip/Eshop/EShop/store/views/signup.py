from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from store.models.products import Product
from store.models.category import Category
from store.models.customers import Customer
from django.contrib import messages
from django.views import View 


class Singup(View):

    def get(self, request):
        return render(request, 'store/signup.html')

    def post(self, request):
        postData = request.POST
        First_name = postData.get('f_name')
        Last_name = postData.get('l_name')
        Email = postData.get('email')
        Email2 = postData.get('email_2')
        Password = postData.get('pass')
        Password2 = postData.get('pass2')
        values = {
            'f_name': First_name,
            'l_name': Last_name,
            'email': Email,
        }
        obj = Customer(first_name=First_name, last_name=Last_name, email=Email, password=Password)

        if not First_name:
            error = 'First name  required'
            messages.success(request, error)
            return render(request, 'store/signup.html', values)
        elif len(First_name) < 3:
            error = 'Char lenght  of First name should be greater than 4'
            messages.success(request, error)
            return render(request, 'store/signup.html', values)
        if Password != Password2:
            messages.success(request, 'Password mismatched')
            return render(request, 'store/signup.html', values)
        elif Email != Email2:
            messages.success(request, 'Email mismatched')
            return render(request, 'store/signup.html', values)
        if obj.isExists():
            messages.success(request, 'Email Address Already exists')
            return render(request, 'store/signup.html', values)
        else:
            obj.password = make_password(Password)
            obj.is_active = True
            obj.register()
            messages.success(request, 'Registration is successful')
            return redirect('store:signup')
