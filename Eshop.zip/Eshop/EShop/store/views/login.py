from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import make_password, check_password
from django.http import HttpResponse
from store.models.products import Product
from store.models.category import Category
from store.models.customers import Customer
from django.contrib import messages
from django.views import View 

class Login(View):
    return_url = None
    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'store/login.html')

    def post(self, request):
        #Login.return_url = request.GET.get('return_url')
        print(Login.return_url)
        email = request.POST.get('email')
        password = request.POST.get('pass')
        obj = Customer()
        data = obj.get_all_customer()
        customer = obj.get_customer_by_email(email)
        if customer:
            flag = check_password(password, make_password(password))
            if flag:
                for item in data:
                    if item.email == email:
                        request.session['customer'] = item.id
                        request.session['name'] = item.first_name + ' ' + item.last_name 
                        request.session['email'] = email
                if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
                else: 
                    Login.return_url = None
                    return redirect('store:home')
            else:
                messages.success(request, 'Email or Password invalid')
        else:
            messages.success(request, 'Email or Password invalid')
    
        return render(request, 'store/login.html')
