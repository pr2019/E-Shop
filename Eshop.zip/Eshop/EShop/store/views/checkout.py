from django.views import View 
from django.shortcuts import render, redirect
from store.models.products import Product
from store.models.orders import OrderedData
from store.models.customers import Customer

class CheckOut(View):
    def post(self, request):
        address = request.POST.get('add')
        pincode = request.POST.get('pin')
        mobile = request.POST.get('mob')
        customer = request.session.get('customer')
        name = request.session.get('name')
        cart = request.session.get('cart')
        products = Product.get_products_by_id(list(cart.keys()))
        # print(address, pincode, mobile, customer, products, cart, name)
        if request.session.get('customer'):
            for product in products:
                # print(product.id)
                # print(cart.get(str(product.id)))
                order = OrderedData(customer=Customer(id=customer), product=product, price = product.price, quantity = cart.get(str(product.id)), address = address, pincode = pincode, mobile = mobile,
                name = name)
                order.place_order()
            
            request.session['cart'] = {} 
            message = 'Thank you for ordering from EasyBusiness. Click on order button to track your order status'
            context = {
                'msg' : message
            }
            return render(request, 'store/display_message.html', {'msg':message})
        else:
            return redirect('store:login')
    
    def get(self, request):
        return render(request, 'store/index.html')