from django.views import View 
from django.shortcuts import render, redirect
from store.models.products import Product
from store.models.orders import OrderedData
from store.models.customers import Customer
from  store.middleware.auth import auth_middleware 
from django.utils.decorators import method_decorator

class OrderView(View):

    # @method_decorator(auth_middleware)
    def get(self, request):
        customer = request.session.get('customer')
        email_id = request.session.get('email')
        # print('customer', customer)
        ordered_data = OrderedData.get_orders_by_customer(customer)
        if not ordered_data: 
            ordered_data = OrderedData.get_orders_by_email(email_id)
        return render(request, 'store/order.html', {'orders':ordered_data})

    def post(self, request):
        pass