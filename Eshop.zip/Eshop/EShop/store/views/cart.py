from django.views import View
from django.shortcuts import render, redirect
from store.models.products import Product

class Cart(View):
    def get(self, request):
        if request.session.get('customer'):
            if  request.session.get('cart'):
                ids = list(request.session.get('cart').keys())
                products = Product.get_products_by_id(ids)
                return render(request, 'store/cart.html', {'products': products})
            else:
                message = 'Cart is empty'
                products = Product.get_all_product()
                return render(request, 'store/display_message.html', {'msg':message, 'products':products})
        else:
            return redirect('store:login')